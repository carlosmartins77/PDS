# npm install express para instalar o express
# node index.js para iniciar o servidor
# npm install --save-dev nodemon
# npm i body-parser
# npm i cors     
# npm i express jsonwebtoken dotenv
# npm i bcrypt
# npm install -g swagger
# npm i supertest
# npm i jest

# token require('crypto').randomBytes#(64).toString('hex')

# 'e573eef32ee554ad4e05682c8acc621176707 80e6d21545dd137ce1b43da9e897c92c5eecb0 d766cb52e530e1d176a0ec99767b33ba98d393 313e2228ce1d92b'#