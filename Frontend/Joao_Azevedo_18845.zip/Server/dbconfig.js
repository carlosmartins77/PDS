var config = {
    user: 'sa',
    password: '1234',
    server: 'localhost',
    database: 'PFSCS',
    options: {
        trustServerCertificate: true,
        enableArithAbort: true,
        instancename: 'SQLEXPRESS'
    },
};

module.exports = config;