import React from 'react';
import NavBar from '../Componentes/NavBar';
import '../Componentes/style.css'
import ContentClientes from '../Componentes/ContentClientes';


const Clientes = () => {
  return (
    <div id='Admin'>
      <NavBar/>
      <ContentClientes></ContentClientes>
    </div>
  );
};

export default Clientes;