import React from 'react';
import NavBar from '../Componentes/NavBar';
import ContentStores from '../Componentes/ContentStores';
import '../Componentes/style.css'

const Admin = () => {
  return (
    <div id='Admin'>
      <NavBar/>
      <ContentStores />
    </div>
  );
};

export default Admin;
