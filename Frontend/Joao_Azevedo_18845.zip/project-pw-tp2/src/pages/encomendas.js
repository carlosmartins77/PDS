import React from 'react';
import NavBar from '../Componentes/NavBar';
import ContentEncomendas from '../Componentes/ContentEncomendas';

import '../Componentes/style.css'

const Encomendas = () => {
  return (
    <div id='Admin'>
      <NavBar/>
      <ContentEncomendas></ContentEncomendas>
    </div>
  );
};

export default Encomendas;