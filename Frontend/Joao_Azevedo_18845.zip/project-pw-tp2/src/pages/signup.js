import React, { useEffect, useState, useContext } from "react";
import "../Componentes/login.css";
import {
  Button,
  FloatingLabel,
  Tabs,
  Tab,
  Form,
  Modal,
} from "react-bootstrap";
import axios from 'axios'
import { NotificationManager } from 'react-notifications';

import useAuth from '../hooks/useAuth';
import { Link, useNavigate, useLocation } from 'react-router-dom';

export default function LogIn() {
  const { setAuth } = useAuth();

  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || '/home';

  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [pwd, setPassword] = useState("")
  const [confirmpwd, setconfirmpassword] = useState("")

  const [error, setError] = useState(false)


  const handleClose = () => setError(false)

  const handleLogin = async (e) => {
    e.preventDefault()
    if (email === "" || pwd === "") {
      setError(true)
      return
    }
    console.log(email, pwd)
    const response = await axios.post("http://localhost:5000/login",
      {
        username: email,
        password: pwd
      });
    localStorage.setItem('user_auth', JSON.stringify(response?.data));
    const names = response?.data?.name
    const tokens = response?.data?.token
    const roles = response?.data?.role

    setAuth({ "name": names, "role": roles, "token": tokens })
    setTimeout(navigate('/home', { replace: true }), 3000)
    //navigate(from, { replace: true });

    //navigate('/home', { replace: true });
  }

  const handleRegister = async (e) => {
    e.preventDefault()
    if (name === "" || email === "" || pwd === "" || confirmpwd === "" || pwd !== confirmpwd) {
      setError(true)
      return
    }

    await axios.post("http://localhost:5000/registeruser",
      {
        name: 'Joao',
        password: '1234567890',
        email: 'a18845@alunos.ipca.pt',
        contact: '925487523',
        nif: '333333333',
        permission: '3'
      })
      .then(res => {
        NotificationManager.success('Registo Efetuado com Sucesso', 'Food Sustentability');
      }
      ).catch(e => {
        NotificationManager.error('Erro Efetuar o Registo', 'Food Sustentability');
      })
  }
  return (
    <>
      <div id='SignUp'>
        <div>
          <div className="centered">
            <div className="row">
              <div className="column" id="left">
                <div className="top-headers">
                  <h1>Food Sustentability</h1>
                </div>
                <Tabs
                  defaultActiveKey="login"
                  id="uncontrolled-tab-example"
                  className="mb-3"
                >
                  <Tab eventKey="login" title="Iniciar sessão">
                    <form className="sign-up-form">
                      <FloatingLabel
                        controlId="floatingInput"
                        label="Endereço email"
                        className="mb-3"
                      >
                        <Form.Control
                          type="email"
                          name="emailLogin"
                          placeholder="nome@exemplo.com"
                          onChange={(e) => setEmail(e.target.value)}
                          value={email}
                          required
                        />
                      </FloatingLabel>
                      <FloatingLabel controlId="floatingPasswordLogin" label="Password">
                        <Form.Control
                          type="password"
                          placeholder="Password"
                          name="passwordLogin"
                          onChange={(e) => setPassword(e.target.value)}
                          value={pwd}
                          required
                        />
                      </FloatingLabel>
                      <div className="submitBTN">
                        <Button variant="primary" size="lg" active onClick={(e) => handleLogin(e)}>
                          Iniciar sessão
                        </Button>
                      </div>
                    </form>
                  </Tab>
                  <Tab eventKey="register" title="Registar">
                    <form className="sign-up-form">
                      <FloatingLabel
                        controlId="floatingInputname"
                        label="Name"
                        className="mb-3"
                      >
                        <Form.Control
                          type="text"
                          name="nameRegister"
                          placeholder="Nome"
                          onChange={(e) => setName(e.target.value)}
                          value={name}
                          required
                        />
                      </FloatingLabel>
                      <FloatingLabel
                        controlId="floatingInputemail"
                        label="Endereço de email"
                        className="mb-3"
                      >
                        <Form.Control
                          type="email"
                          name="emailRegister"
                          placeholder="nome@example.com"
                          onChange={(e) => setEmail(e.target.value)}
                          value={email}
                          required
                        />
                      </FloatingLabel>
                      <FloatingLabel controlId="floatingPasswordRegister" label="Password">
                        <Form.Control
                          type="password"
                          placeholder="Password"
                          name="passwordRegister"
                          onChange={(e) => setPassword(e.target.value)}
                          value={pwd}
                          required
                        />
                      </FloatingLabel>
                      <div className="confirm">
                        <FloatingLabel
                          controlId="floatingConfirmPasswordRegister"
                          label="Confirmar Password"
                        >
                          <Form.Control
                            type="password"
                            placeholder="Confirmar Password"
                            name="confirmpasswordRegister"
                            onChange={(e) => setconfirmpassword(e.target.value)}
                            value={confirmpwd}
                            required
                          />
                        </FloatingLabel>
                      </div>
                      <div className="submitBTN">
                        <Button variant="primary" size="lg" active onClick={(e) => handleRegister(e)}>
                          Registar
                        </Button>
                      </div>
                    </form>
                  </Tab>
                </Tabs>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Modal show={error} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Erro</Modal.Title>
        </Modal.Header>
        <Modal.Body>Por favor, preencha todos os campos.</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Fechar
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
