import React from 'react';
import NavBar from '../Componentes/NavBar.jsx'
import PaginaInicial from '../Componentes/PaginaInicial.jsx'
import '../Componentes/style.css'

const HomeRoutes = () => {
  return (
    <div id='Home'>
      <NavBar></NavBar>
      <PaginaInicial></PaginaInicial>
    </div>
  );
};

export default HomeRoutes;
