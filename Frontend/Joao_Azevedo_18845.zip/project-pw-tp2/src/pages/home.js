import React from 'react';
import NavBar from '../Componentes/NavBarHome.jsx'
import PaginaInicial from '../Componentes/PaginaInicial.jsx'
import '../Componentes/style.css'

const Home = () => {
  return (
    <div id='Home'>
      <NavBar></NavBar>
      <PaginaInicial></PaginaInicial>
    </div>
  );
};

export default Home;
