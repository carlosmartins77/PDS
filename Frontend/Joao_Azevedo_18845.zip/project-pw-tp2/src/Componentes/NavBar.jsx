import React from 'react'
import "./style.css"

import {
  Navbar, Container, Nav, NavDropdown,
} from 'react-bootstrap'

import useAuth from '../hooks/useAuth';

export default function NavBar() {
  const { auth } = useAuth();
  return (
    <>
      <Navbar variant='dark' expand="lg" style={{ backgroundColor: '#14213d', paddingLeft: '5%', paddingRight: '7%' }}>
        <Container fluid>
          <i style={{ color: '#ffc107', marginRight: '10px' }} className="fa-solid fa-bag-shopping fa-2xl"></i>
          <Navbar.Brand style={{ color: 'white', marginLeft: '10px', fontSize: '25px' }} href="/home">Food Sustentability</Navbar.Brand>
          <Navbar.Toggle aria-controls="navbarScroll" />
          <Navbar.Collapse id="navbarScroll">
            <Nav
              className="me-auto my-2 my-lg-0"
              style={{ maxHeight: '100px' }}
              navbarScroll
            >
              <Nav.Link style={{ color: 'white', marginLeft: '6%' }} href="/admin">Admin</Nav.Link>
              <Nav.Link style={{ color: 'white', marginLeft: '6%' }} href="/encomendas">Encomendas</Nav.Link>
              <Nav.Link style={{ color: 'white', marginLeft: '6%' }} href="/clientes">Clientes</Nav.Link>
            </Nav>
            <Nav>
              <NavDropdown title={`${auth.name}`} id="basic-nav-dropdown">
                <NavDropdown.Item href="#action/3.1">Perfil</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.2">Definições</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.3">Termos de Uso</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="/" onClick={() => { localStorage.setItem('user_auth', JSON.stringify({ role: [-1], token: '' })); }}>Log Out</NavDropdown.Item>
              </NavDropdown>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </>
  )
}

