import React, { Component } from "react";
import { Link, useNavigate } from "react-router-dom";

const Unauthorized = () => {
    const navigate = useNavigate();

    const goBack = () => navigate(-1);

    return (
        <div className="not-found-wrap text-center" style={{marginTop: '100px'}}>
        <h1 className="text-60">Unauthorized</h1>
        <p className="mb-5  text-muted text-18">
            Não possui permissão para ver este página.
        </p>
        <Link to="/" className="btn btn-lg btn-primary btn-rounded" onClick={goBack}>
            Voltar ao Inicio
        </Link>
    </div>
    )
}

export default Unauthorized
