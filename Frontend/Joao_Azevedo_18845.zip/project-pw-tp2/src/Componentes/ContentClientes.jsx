import React, { useState, useEffect } from 'react'
import axios from "axios";
import 'react-notifications/lib/notifications.css';
import { OverlayTrigger, Popover, Badge } from 'react-bootstrap'
import swal from "sweetalert2";
import ReactPaginate from 'react-paginate';
import { MdCancel, MdCheckCircle } from "react-icons/md";
import { AiFillFolderOpen, AiOutlineCloseSquare, AiFillPlusCircle } from "react-icons/ai";
import { FiEdit } from "react-icons/fi";
import { NotificationContainer, NotificationManager } from 'react-notifications';
import useAuth from '../hooks/useAuth';

export default function ContentEncomendas() {
    const [searchStore, setsearchStore] = useState('');
    const [totallist, settotallist] = useState([]);
    const [activesearch, setactivesearch] = useState(false);
    const [stores, setstores] = useState([]);
    const [rowsPerPage, setrowsPerPage] = useState(10);
    const [page, setpage] = useState(0);

    const [showViewerDialog, setshowViewerDialog] = useState(false);
    const [formEdit, setformEdit] = useState(false);
    const [viewerValues, setviewerValues] = useState([]);

    const { auth } = useAuth();

    const handleEditList = async (requestExpense) => {

    }

    const getStores = async () => {
        await axios.get("http://localhost:5000/cliente/listarProdutos",
            {
                headers: {
                    'Content-type': 'application/json',
                    'Authorization': `Bearer ${auth.token}`
                }
            })
            .then(res => {
                setstores(res.data)
                console.log(res.data)
            }).catch(e => {
                throw (e)
            })
    };

    const handleApproveStore = async (data, status) => {
        console.clear()

    };

    useEffect(() => {
        getStores()
    }, []);

    const handleSearchValue = async (event) => {
        setsearchStore(event.target.value)
        if (searchStore != "") {
            await handleSearch(event.target.value)
            setactivesearch(true)
            console.log(searchStore)
            console.log(activesearch)
            return
        }
        setactivesearch(false)
        console.log(activesearch)
    }

    const handleSearch = async (word) => {
        let val = stores.filter((val) => {
            if (word == "") return
            else if (val.nomeProduto.toLowerCase().includes(word.toLowerCase())) {
                return val
            }
        })
        await settotallist(val)
        await setactivesearch(true)
        console.log("Lista:", totallist)
    };

    const handlePageClick = data => {
        console.log(data)
        let pa = data.selected;
        setpage(pa);
    };

    return (
        <div>
            <section className="contact-list p-4">
                <NotificationContainer />
                <div className="row" >
                    <div className="col-md-12 mb-4" >

                        <div className="card text-left" style={{ backgroundColor: '#14213d', border: '1px solid white', borderRadius: '10px', opacity: '0.9' }}>
                            <div className="row px-2 mt-8 d-flex align-items-center">

                                <div className="card-header  bg-transparent col-sm-6 col-md-6 mt-md-2">
                                    <div
                                        className="d-flex card-title align-items-center justify-content-between mb-0">
                                        <input type="text"
                                            className="form-control form-control-rounded "
                                            placeholder="Filtrar por Nome do Produto"
                                            onChange={(event) => {
                                                handleSearchValue(event)
                                            }}
                                        />
                                    </div>
                                </div>
                            </div>

                            {/*Tabela para exibir as infos */}
                            <div className="card-body pt-1 mb-4">
                                <div className="table-responsive">
                                    <table id="ul-contact-list"
                                        className="display table text-center table-striped w-100"
                                        style={{ color: 'white' }}
                                    >
                                        <thead style={{ color: 'white' }}>
                                            <tr>
                                                <th># Produto</th>
                                                <th>Nome</th>
                                                <th># loja</th>
                                                <th># SubCategoria do Produto</th>
                                                <th>Preço</th>
                                                <th>Quantidade</th>
                                                <th>Opções</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                activesearch === true ?
                                                    totallist.slice(rowsPerPage * page, rowsPerPage * (page + 1))
                                                        .map((data) => (<tr key={data.idProduto}>
                                                            <td style={{ color: 'white' }}>{data.idProduto}</td>
                                                            <td style={{ color: 'white' }}>{data.nomeProduto}</td>
                                                            <td style={{ color: 'white' }}>{data.lojaId}</td>
                                                            <td style={{ color: 'white' }}>{data.SubcategoriaProdId}</td>
                                                            <td style={{ color: 'white' }}>{data.preco}</td>
                                                            <td style={{ color: 'white' }}>{data.quantidade}</td>
                                                            <td>
                                                                {
                                                                    <div className="d-flex justify-content-around">
                                                                        <div className="cursor-pointer">
                                                                            <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                <Popover>
                                                                                    <strong>Aumentar a Quantidade</strong>
                                                                                </Popover>
                                                                            }>
                                                                                <div className="cursor-pointer ">
                                                                                    <AiFillPlusCircle
                                                                                        className="text-warning"
                                                                                        size={19}
                                                                                        key={data.idProduto}
                                                                                    />
                                                                                </div>
                                                                            </OverlayTrigger>
                                                                        </div>
                                                                        <div className="cursor-pointer ">
                                                                            <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                <Popover>
                                                                                    <strong>Adicionar ao Carrrinho</strong>
                                                                                </Popover>
                                                                            }>
                                                                                <div className="cursor-pointer ">
                                                                                    <MdCheckCircle
                                                                                        className="text-success"
                                                                                        size={19}
                                                                                    //onClick={() => { handleApproveStore(data, 1) }}
                                                                                    />
                                                                                </div>
                                                                            </OverlayTrigger>
                                                                        </div>


                                                                    </div>
                                                                }
                                                            </td>
                                                        </tr>))
                                                    :
                                                    stores.slice(rowsPerPage * page, rowsPerPage * (page + 1))
                                                        .map((data) => (<tr key={data.idProduto}>
                                                            <td style={{ color: 'white' }}>{data.idProduto}</td>
                                                            <td style={{ color: 'white' }}>{data.nomeProduto}</td>
                                                            <td style={{ color: 'white' }}>{data.lojaId}</td>
                                                            <td style={{ color: 'white' }}>{data.SubcategoriaProdId}</td>
                                                            <td style={{ color: 'white' }}>{data.preco}</td>
                                                            <td style={{ color: 'white' }}>{data.quantidade}</td>
                                                            <td>
                                                                {
                                                                    <div className="d-flex justify-content-around">
                                                                        <div className="cursor-pointer">
                                                                            <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                <Popover>
                                                                                    <strong>Aumentar a Quantidade</strong>
                                                                                </Popover>
                                                                            }>
                                                                                <div className="cursor-pointer ">
                                                                                    <AiFillPlusCircle
                                                                                        className="text-warning"
                                                                                        size={19}
                                                                                        key={data.idProduto}
                                                                                    />
                                                                                </div>
                                                                            </OverlayTrigger>
                                                                        </div>
                                                                        <div className="cursor-pointer ">
                                                                            <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                <Popover>
                                                                                    <strong>Adicionar ao Carrrinho</strong>
                                                                                </Popover>
                                                                            }>
                                                                                <div className="cursor-pointer ">
                                                                                    <MdCheckCircle
                                                                                        className="text-success"
                                                                                        size={19}
                                                                                        //onClick={() => { handleApproveStore(data, 1) }}
                                                                                    />
                                                                                </div>
                                                                            </OverlayTrigger>
                                                                        </div>


                                                                    </div>
                                                                }
                                                            </td>
                                                        </tr>))
                                            }
                                        </tbody>
                                    </table>
                                </div>
                                <div className="d-flex justify-content-end mr-lg-4">
                                    <ReactPaginate
                                        breakLabel="..."
                                        nextLabel="next >"
                                        onPageChange={handlePageClick}
                                        pageRangeDisplayed={rowsPerPage}
                                        pageCount={Math.ceil(stores.length / rowsPerPage)}
                                        previousLabel="< previous"
                                        renderOnZeroPageCount={null}
                                        containerClassName={"pagination"}
                                        pageClassName={"page-num"}
                                        previousClassName={"page-num"}
                                        nextClassName={"page-num"}
                                        activeClassName={"active"}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    )
}
