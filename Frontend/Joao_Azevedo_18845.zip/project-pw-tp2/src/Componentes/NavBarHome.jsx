import React from 'react'
import {
    Navbar, Container, Nav, NavDropdown, FormControl, Form, Button
} from 'react-bootstrap'


export default function NavBarHome() {
    return (
        <div>
            <Navbar variant='dark' expand="lg" style={{ backgroundColor: '#14213d', paddingLeft: '5%', paddingRight: '7%' }}>
                <Container fluid>
                    <i style={{ color: '#ffc107', marginRight: '10px' }} className="fa-solid fa-bag-shopping fa-2xl"></i>
                    <Navbar.Brand style={{ color: 'white', marginLeft: '10px', fontSize: '25px' }} href="/">Food Sustentability</Navbar.Brand>
                    <Navbar.Toggle aria-controls="navbarScroll" />
                    <Navbar.Collapse id="navbarScroll">
                        <Nav
                            className="me-auto my-2 my-lg-0"
                            style={{ maxHeight: '100px' }}
                            navbarScroll
                        >
                        </Nav>
                        <Button style={{ marginRight: '6%' }} variant="outline-warning" href='/login'>Log In</Button>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </div>
    )
}
