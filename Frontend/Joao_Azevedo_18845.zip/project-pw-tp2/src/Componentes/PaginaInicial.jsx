import React from 'react'
import { Carousel, Popover, Badge, Card } from 'react-bootstrap'
import { FaInstagram, FaTwitter, FaLinkedin, FaYoutube } from "react-icons/fa";

export default function PaginaInicial() {
    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '700px' }}>
            <div style={{ paddingLeft: '10%', width: '850px', display: 'flex', alignItems: 'center', height: '700px', marginBottom: '4%' }}>
                <div style={{ fontSize: '86px', color: '#14213d' }}>
                    Salva Comida,
                    Ajuda o Planeta
                </div>
            </div>
            <div style={{ width: '1900px', display: 'flex', justifyContent: 'center', alignItems: 'center', height: '700px' }}>

                <Carousel style={{ width: '600px', heigh: '500px', borderRadius: '13px', color: 'black' }}>
                    <Carousel.Item interval={6000}>
                        <Card style={{ borderRadius: '15px' }}>
                            <Card.Img variant="top" src="https://images.unsplash.com/photo-1496412705862-e0088f16f791?ixlib=rb-1.2.1&raw_url=true&q=60&fm=jpg&crop=entropy&cs=tinysrgb&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTh8fGZvb2R8ZW58MHwwfDB8fA%3D%3D&auto=format&fit=crop&w=500" />
                            <Card.Body>
                                <Card.Title>Salva a Comida</Card.Title>
                                <Card.Text>
                                    Na Food Sustentability, sonhamos com um planeta sem desperdício alimentar e, todos os dias, trabalhamos arduamente para que este sonho se torne realidade.
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Carousel.Item>
                    <Carousel.Item interval={6000}>
                        <Card style={{ borderRadius: '15px' }}>
                            <Card.Img variant="top" src="https://images.unsplash.com/photo-1498557850523-fd3d118b962e?ixlib=rb-1.2.1&raw_url=true&q=60&fm=jpg&crop=entropy&cs=tinysrgb&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MzN8fGZydWl0fGVufDB8MHwwfHw%3D&auto=format&fit=crop&w=500" />
                            <Card.Body>
                                <Card.Title>Acreditamos na Mudança</Card.Title>
                                <Card.Text>
                                    Para ter impacto e mudar o panorama do desperdício alimentar, precisamos de trabalhar não só na educação dos mais novos, mas também na mudança dos hábitos de consumo dos mais velhos.
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Carousel.Item>
                    <Carousel.Item interval={6000}>
                        <Card style={{ borderRadius: '15px' }}>
                            <Card.Img variant="top" src="https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?crop=entropy&cs=tinysrgb&fm=jpg&ixlib=rb-1.2.1&q=60&raw_url=true&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MzF8fGJ1c2luZXNzfGVufDB8MHwwfHw%3D&auto=format&fit=crop&w=500" />
                            <Card.Body>
                                <Card.Title>Uma Solução Simples Para os Negócios</Card.Title>
                                <Card.Text>
                                    Adoramos dar as boas-vindas a parceiros que tenham a mesma vontade que nós de combater o desperdício alimentar.
                                    Só existem benefícios para o planeta e para si.
                                </Card.Text>
                            </Card.Body>
                        </Card>
                    </Carousel.Item>
                </Carousel>
            </div>
            <div style={{ marginTop: '24%' , marginRight: '2%', width: '30px', height: '190px'}}>
                <FaInstagram size={24} style={{ marginBottom: '20px', color: '#14213d'}}></FaInstagram>
                <FaTwitter size={24} style={{ marginBottom: '20px', color: '#14213d'}}></FaTwitter>
                <FaLinkedin size={24} style={{ marginBottom: '20px', color: '#14213d'}}></FaLinkedin>
                <FaYoutube size={24} style={{ marginBottom: '20px', color: '#14213d'}}></FaYoutube>
            </div>
        </div>
    )
}
