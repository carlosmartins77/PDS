import React, { useState, useEffect } from 'react'
import axios from "axios";
import 'react-notifications/lib/notifications.css';
import { OverlayTrigger, Popover, Badge } from 'react-bootstrap'
import swal from "sweetalert2";
import ReactPaginate from 'react-paginate';
import { MdCancel, MdCheckCircle } from "react-icons/md";
import { AiFillFolderOpen, AiOutlineCloseSquare } from "react-icons/ai";
import { FiEdit } from "react-icons/fi";
import { NotificationContainer, NotificationManager } from 'react-notifications';
import EditStore from './EditStore';

import useAuth from '../hooks/useAuth';


export default function ContentStores() {
    const [searchStore, setsearchStore] = useState('');
    const [totallist, settotallist] = useState([]);
    const [activesearch, setactivesearch] = useState(false);
    const [stores, setstores] = useState([]);
    const [rowsPerPage, setrowsPerPage] = useState(5);
    const [page, setpage] = useState(0);
    const [cardInfo, setcardInfo] = useState([
        {
            icon: "fa-solid fa-list-check fa-2xl",
            color: "text-warning",
            title: "Lojas Aprovadas",
            amount: 0
        },
        {
            icon: "fa-solid fa-list fa-2xl",
            color: "text-warning",
            title: "Lojas Em Espera",
            amount: 0
        },
        {
            icon: "fa-solid fa-calendar-xmark fa-2xl",
            color: "text-warning",
            title: "Lojas Reprovadas",
            amount: 0,
        },
    ]);

    const [showViewerDialog, setshowViewerDialog] = useState(false);
    const [formEdit, setformEdit] = useState(false);
    const [viewerValues, setviewerValues] = useState([]);

    const { auth } = useAuth();


    const handleViewer = async arg => {

        if (arg && arg.toString()) {
            await setviewerValues(arg);
            await setshowViewerDialog(true);
            await setformEdit(false);
        } else {
            await setviewerValues([]);
            await setshowViewerDialog(!showViewerDialog);
        }
    };

    const handleEditList = async (requestExpense) => {
        console.log("Editar", requestExpense);
        console.log("Editar", requestExpense.morada);
        console.log("Editar", requestExpense.nif);
        console.log("Editar", requestExpense.nomeloja);
        await axios.post("http://localhost:5000/editStores",
            {
                id: requestExpense.id,
                nome: requestExpense.nomeloja,
                morada: requestExpense.morada,
                nif: requestExpense.nif
            },
            {
                headers: {
                    'Content-type': 'application/json',
                    'Authorization': `Bearer ${auth.token}`
                }
            }
        )
            .then(res => console.log(res.data)).catch(e => {
                throw (e)
            })


        await getStores()
    }

    const getStores = async () => {
        await axios.get("http://localhost:5000/listalojas",
            {
                headers: {
                    'Content-type': 'application/json',
                    'Authorization': `Bearer ${auth.token}`
                }
            })
            .then(res => {
                console.log(res.data)
                setstores(res.data)
            }).catch(e => {
                throw (e)
            })
    };

    const deleteStores = async (data) => {
        await axios.delete(`http://localhost:5000/deleteStores/${data.idLoja}`,
            {
                headers: {
                    'Content-type': 'application/json',
                    'Authorization': `Bearer ${auth.token}`
                }
            })
            .then(res => console.log(res.data)).catch(e => {
                throw (e)
            })

        await getStores()
    };

    const getStoresData = async () => {
        await axios.get("http://localhost:5000/allAproveStores",
            {
                headers: {
                    'Content-type': 'application/json',
                    'Authorization': `Bearer ${auth.token}`
                }
            })
            .then(res => {
                let list = [...cardInfo]
                list[0].amount = res.data
                console.log(list)
                setcardInfo(list)
            }).catch(e => {
                throw (e)
            })
        await axios.get("http://localhost:5000/allStores",
            {
                headers: {
                    'Content-type': 'application/json',
                    'Authorization': `Bearer ${auth.token}`
                }
            })
            .then(res => {
                let list = [...cardInfo]
                list[1].amount = res.data
                console.log(list)
                setcardInfo(list)
            }).catch(e => {
                throw (e)
            })
        await axios.get("http://localhost:5000/allReproveStores",
            {
                headers: {
                    'Content-type': 'application/json',
                    'Authorization': `Bearer ${auth.token}`
                }
            })
            .then(res => {
                let list = [...cardInfo]
                list[2].amount = res.data
                console.log(list)
                setcardInfo(list)
            }).catch(e => {
                throw (e)
            })
    };

    const handleApproveStore = async (data, status) => {
        await axios.put("http://localhost:5000/aprovacaoLoja",
            {
                "idLoja": parseInt(data.idLoja),
                "aprovacao": parseInt(status)
            },
            {
                headers: {
                    'Content-type': 'application/json',
                    'Authorization': `Bearer ${auth.token}`
                }
            })
            .then(res => {
                var res

                if (status === 1) {
                    res = 'Aprovada'
                }
                else {
                    res = 'Reprovada'
                }
                NotificationManager.success('Loja ' + res + ' com Sucesso', 'Food Sustentability');
            }).catch(e => {
                var res1

                if (status === 1) {
                    res1 = 'Aprovar'
                }
                else {
                    res1 = 'Reprovar'
                }
                NotificationManager.error('Erro ao ' + res1 + ' a loja', 'Food Sustentability');
            })

        await getStores()
        await getStoresData()
    };

    useEffect(() => {
        getStores()
        getStoresData()
    }, []);

    const handleSearchValue = async (event) => {
        setsearchStore(event.target.value)
        if (searchStore != "") {
            await handleSearch(event.target.value)
            setactivesearch(true)
            console.log(searchStore)
            console.log(activesearch)
            return
        }
        setactivesearch(false)
        console.log(activesearch)
    }

    const handleSearch = async (word) => {
        let val = stores.filter((val) => {
            if (searchStore == "") return
            else if (val.nomeloja.toLowerCase().includes(word.toLowerCase())) {
                return val
            } else if (val.morada.toLowerCase().includes(word.toLowerCase())) {
                return val
            } else if (val.nome.toLowerCase().includes(word.toLowerCase())) {
                return val
            }
        })
        await settotallist(val)
        await setactivesearch(true)
        console.log("Lista:", totallist)
    };

    const handlePageClick = data => {
        console.log(data)
        let pa = data.selected;
        setpage(pa);
    };

    const getBadgeColor = role => {
        if (role === 0) return "warning"
        else if (role === 1) return "success"
        else if (role === 2) return "danger"
        else return "badge-secondary"
    };

    return (
        <div>
            <div className="separator-breadcrumb border-top" />
            <section className="ul-widget-stat-s3">
                <div className="row p-4">
                    {cardInfo.map((item, ind) => (
                        <div className={" col-md-4 col-lg-4 mt-4"} key={ind}>
                            <div className={"card mb-2"} style={{ backgroundColor: '#14213d', border: '1px solid white', color: 'white', borderRadius: '10px', opacity: '0.9' }}>
                                <div className="card-body">
                                    <div className="ul-widget__row">
                                        <div className="ul-widget__content">
                                            <i style={{ float: 'right', marginTop: '6%', marginRight: '3%' }} className={item.title == "N" ? "i-Happy text-success" : `${item.icon} ${item.color}`} />
                                            <p className="m-0" style={{ fontSize: '20px' }}>{item.title}</p>
                                            <h4 className="heading">{item.amount}</h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            <section className="contact-list p-4">
                <NotificationContainer />
                <div className="row" >
                    <div className="col-md-12 mb-4" >

                        <div className="card text-left" style={{ backgroundColor: '#14213d', border: '1px solid white', borderRadius: '10px', opacity: '0.9' }}>
                            <div className="row px-2 mt-8 d-flex align-items-center">

                                <div className="card-header  bg-transparent col-sm-6 col-md-6 mt-md-2">
                                    <div
                                        className="d-flex card-title align-items-center justify-content-between mb-0">
                                        <input type="text"
                                            className="form-control form-control-rounded "
                                            placeholder="Filtrar por Nome, Morada e Categoria..."
                                            onChange={(event) => {
                                                handleSearchValue(event)
                                            }}
                                        />
                                    </div>
                                </div>
                            </div>

                            {/*Tabela para exibir as infos */}
                            <div className="card-body pt-1 mb-4">
                                <div className="table-responsive">
                                    <table id="ul-contact-list"
                                        className="display table text-center table-striped w-100"
                                        style={{ color: 'white' }}
                                    >
                                        <thead style={{ color: 'white' }}>
                                            <tr>
                                                <th>#</th>
                                                <th>Nome</th>
                                                <th>Morada</th>
                                                <th>Nif</th>
                                                <th>Categoria</th>
                                                <th>Estado</th>
                                                <th>Opções</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                //console.log(stores)

                                                activesearch === true ?
                                                    totallist.slice(rowsPerPage * page, rowsPerPage * (page + 1))
                                                        .map((data) => (<tr key={data.idLoja}>
                                                            <td style={{ color: 'white' }}>{data.idLoja}</td>
                                                            <td style={{ color: 'white' }}>{data.nomeloja}</td>
                                                            <td style={{ color: 'white' }}>{data.morada}</td>
                                                            <td style={{ color: 'white' }}>{data.nif}</td>
                                                            <td style={{ color: 'white' }}>{data.nome}</td>
                                                            <td><span>
                                                                <Badge style={{ color: 'white' }} bg={getBadgeColor(data.aprovacao)}>{data.aprovacao === 0 ? "Por Aprovar" : data.aprovacao === 1 ? "Aprovado" : "Reprovado"}</Badge>
                                                            </span></td>
                                                            <td>
                                                                {
                                                                    data.aprovacao == 0 ?
                                                                        <div className="d-flex justify-content-around">
                                                                            <div className="cursor-pointer">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Download Ficheiro</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <a href='http://localhost:5000/testarficheiro' target='_blank' rel='noopener noreferrer'>
                                                                                            <AiFillFolderOpen
                                                                                                className="text-warning"
                                                                                                size={19}
                                                                                                key={data.TID}
                                                                                            />
                                                                                        </a>
                                                                                    </div>
                                                                                </OverlayTrigger>

                                                                            </div>
                                                                            <div className="cursor-pointer ">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Aprovar Loja</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <MdCheckCircle
                                                                                            className="text-success"
                                                                                            size={19}
                                                                                            onClick={() => { handleApproveStore(data, 1) }}
                                                                                        />
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                            <div className="cursor-pointer ">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Editar Loja</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <FiEdit
                                                                                            className="text-info"
                                                                                            size={19}
                                                                                            onClick={() => { handleViewer(data) }}
                                                                                        />
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                            <div className="cursor-pointer ">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Recusar Loja</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <MdCancel
                                                                                            className="text-danger"
                                                                                            size={19}
                                                                                            onClick={() => {
                                                                                                swal
                                                                                                    .fire({
                                                                                                        title: "Tem a certeza?",
                                                                                                        text: "Recusar a Loja com o ID #" + data.idLoja,
                                                                                                        icon: "warning",
                                                                                                        type: "question",
                                                                                                        showCancelButton: true,
                                                                                                        confirmButtonColor: "#3085d6",
                                                                                                        cancelButtonColor: "#d33",
                                                                                                        confirmButtonText: "Sim, recusar!",
                                                                                                        cancelButtonText: "Não"
                                                                                                    })
                                                                                                    .then(result => {
                                                                                                        if (result.value) {
                                                                                                            handleApproveStore(data, 2)
                                                                                                            swal.fire(
                                                                                                                "Apagado!",
                                                                                                                "O pedido foi eliminado",
                                                                                                                "Erro"
                                                                                                            );

                                                                                                        }
                                                                                                    });
                                                                                            }}
                                                                                        />
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                            <div className="cursor-pointer ">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Apagar Loja</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <AiOutlineCloseSquare
                                                                                            className="text-info"
                                                                                            size={19}
                                                                                            onClick={() => { deleteStores(data) }}
                                                                                        />
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                        </div>
                                                                        :
                                                                        <div className="d-flex justify-content-around">
                                                                            <div className="cursor-pointer">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Download Ficheiro</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <a href='http://localhost:5000/testarficheiro' target='_blank' rel='noopener noreferrer'>
                                                                                            <AiFillFolderOpen
                                                                                                className="text-warning"
                                                                                                size={19}
                                                                                                key={data.TID}
                                                                                            />
                                                                                        </a>
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                            <div className="cursor-pointer ">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Editar Loja</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <FiEdit
                                                                                            className="text-info"
                                                                                            size={19}
                                                                                            onClick={() => { handleViewer(data) }}
                                                                                        />
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                            <div className="cursor-pointer ">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Apagar Loja</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <AiOutlineCloseSquare
                                                                                            className="text-info"
                                                                                            size={19}
                                                                                            onClick={() => { deleteStores(data) }}
                                                                                        />
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                        </div>
                                                                }
                                                            </td>
                                                        </tr>))
                                                    :
                                                    stores.slice(rowsPerPage * page, rowsPerPage * (page + 1))
                                                        .map((data) => (<tr key={data.idLoja}>
                                                            <td style={{ color: 'white' }}>{data.idLoja}</td>
                                                            <td style={{ color: 'white' }}>{data.nomeloja}</td>
                                                            <td style={{ color: 'white' }}>{data.morada}</td>
                                                            <td style={{ color: 'white' }}>{data.nif}</td>
                                                            <td style={{ color: 'white' }}>{data.nome}</td>
                                                            <td><span>
                                                                <Badge style={{ color: 'white' }} bg={getBadgeColor(data.aprovacao)}>{data.aprovacao === 0 ? "Por Aprovar" : data.aprovacao === 1 ? "Aprovado" : "Reprovado"}</Badge>
                                                            </span></td>
                                                            <td>
                                                                {
                                                                    data.aprovacao == 0 ?
                                                                        <div className="d-flex justify-content-around">
                                                                            <div className="cursor-pointer">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Download Ficheiro</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <a href='http://localhost:5000/testarficheiro' target='_blank' rel='noopener noreferrer'>

                                                                                            <AiFillFolderOpen
                                                                                                className="text-warning"
                                                                                                size={19}
                                                                                                key={data.TID}
                                                                                            />
                                                                                        </a>
                                                                                    </div>
                                                                                </OverlayTrigger>

                                                                            </div>
                                                                            <div className="cursor-pointer ">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Aprovar Loja</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <MdCheckCircle
                                                                                            className="text-success"
                                                                                            size={19}
                                                                                            onClick={() => { handleApproveStore(data, 1) }}
                                                                                        />
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                            <div className="cursor-pointer ">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Editar Loja</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <FiEdit
                                                                                            className="text-info"
                                                                                            size={19}
                                                                                            onClick={() => { handleViewer(data) }}
                                                                                        />
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                            <div className="cursor-pointer ">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Recusar Loja</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <MdCancel
                                                                                            className="text-danger"
                                                                                            size={19}
                                                                                            onClick={() => {
                                                                                                swal
                                                                                                    .fire({
                                                                                                        title: "Tem a certeza?",
                                                                                                        text: "Recusar a Loja com o ID #" + data.idLoja,
                                                                                                        icon: "warning",
                                                                                                        type: "question",
                                                                                                        showCancelButton: true,
                                                                                                        confirmButtonColor: "#3085d6",
                                                                                                        cancelButtonColor: "#d33",
                                                                                                        confirmButtonText: "Sim, recusar!",
                                                                                                        cancelButtonText: "Não"
                                                                                                    })
                                                                                                    .then(result => {
                                                                                                        if (result.value) {
                                                                                                            handleApproveStore(data, 2)
                                                                                                            swal.fire(
                                                                                                                "Apagado!",
                                                                                                                "O pedido foi eliminado",
                                                                                                                "Erro"
                                                                                                            );

                                                                                                        }
                                                                                                    });
                                                                                            }}
                                                                                        />
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                            <div className="cursor-pointer ">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Apagar Loja</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <AiOutlineCloseSquare
                                                                                            className="text-info"
                                                                                            size={19}
                                                                                            onClick={() => { deleteStores(data) }}
                                                                                        />
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                        </div>
                                                                        :
                                                                        <div className="d-flex justify-content-around">
                                                                            <div className="cursor-pointer">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Download Ficheiro</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <a href='http://localhost:5000/testarficheiro' target='_blank' rel='noopener noreferrer'>
                                                                                            <AiFillFolderOpen
                                                                                                className="text-warning"
                                                                                                size={19}
                                                                                                key={data.TID}
                                                                                            />
                                                                                        </a>
                                                                                    </div>
                                                                                </OverlayTrigger>

                                                                            </div>
                                                                            <div className="cursor-pointer ">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Editar Loja</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <FiEdit
                                                                                            className="text-info"
                                                                                            size={19}
                                                                                            onClick={() => { handleViewer(data) }}
                                                                                        />
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                            <div className="cursor-pointer ">
                                                                                <OverlayTrigger trigger={["hover", "hover"]} placement="top" overlay={
                                                                                    <Popover>
                                                                                        <strong>Apagar Loja</strong>
                                                                                    </Popover>
                                                                                }>
                                                                                    <div className="cursor-pointer ">
                                                                                        <AiOutlineCloseSquare
                                                                                            className="text-info"
                                                                                            size={19}
                                                                                            onClick={() => { deleteStores(data) }}
                                                                                        />
                                                                                    </div>
                                                                                </OverlayTrigger>
                                                                            </div>
                                                                        </div>
                                                                }
                                                            </td>
                                                        </tr>))
                                            }
                                        </tbody>
                                    </table>
                                </div>
                                <div className="d-flex justify-content-end mr-lg-4">
                                    <ReactPaginate
                                        breakLabel="..."
                                        nextLabel="next >"
                                        onPageChange={handlePageClick}
                                        pageRangeDisplayed={rowsPerPage}
                                        pageCount={Math.ceil(stores.length / rowsPerPage)}
                                        previousLabel="< previous"
                                        renderOnZeroPageCount={null}
                                        containerClassName={"pagination"}
                                        pageClassName={"page-num"}
                                        previousClassName={"page-num"}
                                        nextClassName={"page-num"}
                                        activeClassName={"active"}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <EditStore
                show={showViewerDialog}
                showViewerDialog={handleViewer}
                initialValues={viewerValues}
                handleFormSubmit={handleEditList}
            />
        </div>
    )
}
