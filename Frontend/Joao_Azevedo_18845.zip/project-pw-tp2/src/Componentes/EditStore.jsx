import React, { useState } from "react";
import {
    Modal,
    FormLabel,
    Accordion,
    Card,
    Table, Button,
    Form, FormControl, FormGroup
} from "react-bootstrap";
import { Field, Formik, useFormikContext, useField, ErrorMessage } from "formik";
import * as yup from "yup";
import "./modal.css";
import moment from "moment";
import { MdCancel } from "react-icons/md";

const EditStore = ({
    show,
    showViewerDialog,
    initialValues,
    handleFormSubmit,
}) => {
    return (
        <Modal show={Boolean(show)} onHide={showViewerDialog} centered size="lg" dialogClassName="custom_size" scrollable={true}>
            <div className="modal-header  bg-warning">
                <h5 className="modal-title text-white" id="exampleModalLabel">
                    <b>{'Editar Loja Nº' + initialValues.idLoja}</b>
                </h5>
                <MdCancel
                    style={{ color: 'white' , cursor: 'pointer'}}
                    size={22}
                    onClick={() => showViewerDialog(false)}></MdCancel>
            </div>
            <div className="modal-body" style={{ height: "360px" }}>
                <Formik
                    initialValues={{
                        nomeloja: initialValues.nomeloja === "null" ? '' : initialValues.nomeloja || null,
                        morada: initialValues.morada === "null" ? '' : initialValues.morada || null,
                        nif: initialValues.nif === "null" ? null : initialValues.nif || null,
                        id: initialValues.idLoja === "null" ? null : initialValues.idLoja || null,
                    }}
                    onSubmit={handleFormSubmit}
                    validationSchema={ruleSchema}
                    enableReinitialize={true}
                >
                    {({
                        values,
                        errors,
                        touched,
                        handleChange,
                        handleBlur,
                        handleSubmit,
                        isSubmitting

                    }) => (
                        <Form onSubmit={handleSubmit} className="position-relative">
                            <Form.Group>
                                <Form.Label column className="text-warning">
                                    <b>Nome da Loja:</b>
                                </Form.Label>
                                <div
                                    className="col-md-5">
                                    <Form.Control
                                        className="col-sm-12"
                                        placeholder="Nome da Loja"
                                        name="nomeloja"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        isInvalid={errors.nomeloja && touched.nomeloja}
                                        defaultValue={initialValues.nomeloja}
                                    /></div>
                            </Form.Group>
                            <ErrorMessage name="nomeloja"
                                          render={msg => <p className={"text-danger"}>{msg}</p>}/>
                            <Form.Group>
                                <Form.Label column className="text-warning">
                                    <b>Morada:</b>
                                </Form.Label>
                                <div
                                    className="col-md-5">
                                    <Form.Control
                                        className="col-sm-12"
                                        placeholder="Morada"
                                        name="morada"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        isInvalid={errors.morada && touched.morada}
                                        defaultValue={initialValues.morada}
                                    /></div>
                            </Form.Group>
                            <ErrorMessage name="morada"
                                          render={msg => <p className={"text-danger"}>{msg}</p>}/>
                            <Form.Group>
                                <Form.Label column className="text-warning">
                                    <b>Nif:</b>
                                </Form.Label>
                                <div
                                    className="col-md-5">
                                    <Form.Control
                                        className="col-sm-12"
                                        placeholder="Nif"
                                        name="nif"
                                        onChange={handleChange}
                                        onBlur={handleBlur}
                                        isInvalid={errors.nif && touched.nif}
                                        defaultValue={initialValues.nif}
                                    /></div>
                            </Form.Group>
                            <ErrorMessage name="nif"
                                          render={msg => <p className={"text-danger"}>{msg}</p>}/>
                            <Form.Group style={{ marginTop: "2.5rem"}}>
                                <Button type="submit" className="btn btn-warning mr-3" style={{  color: 'White'}} disabled={isSubmitting}>
                                    Submeter
                                </Button>
                            </Form.Group>
                        </Form>
                    )}
                </Formik>
            </div>
        </Modal >
    );
};

const ruleSchema = yup.object().shape({
    nomeloja: yup.string().required("Por favor seleciona um nome"),
    nif: yup.number().required("Por favor seleciona um nif"),
    morada: yup.string().required("Por favor seleciona uma morada"),
})


export default EditStore;
