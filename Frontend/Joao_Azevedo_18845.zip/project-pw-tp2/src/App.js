import './App.css';
import {
  Routes,
  Route,
} from "react-router-dom";

import Admin from './pages/admin'
import Home from './pages/home'
import HomeRoutes from './pages/homeRoutes'
import Encomendas from './pages/encomendas'
import Clientes from './pages/clientes'
import LogIn from './pages/signup'

import Missing from './Componentes/Missing';
import Unauthorized from './Componentes/Unauthorized';
import RequireAuth from './Componentes/RequireAuth';

import Layout from './Componentes/Layout';

const ROLES = {
  'UserCliente': 3,
  'UserStore': 2,
  'Admin': 1
}

function App() {
  return (
    <Routes>

      <Route path='/' element={<Home/>} />

      {/* public routes*/}
      <Route path='login' element={<LogIn />} />
      <Route path="unauthorized" element={<Unauthorized />} />

      {/* we want to protect these routes*/}
      <Route element={<RequireAuth allowedRoles={[ROLES.UserCliente, ROLES.Admin, ROLES.UserStore]} />}>
        <Route path='/home' element={<HomeRoutes />} />
      </Route>
      <Route element={<RequireAuth allowedRoles={[ROLES.UserCliente, ROLES.Admin]} />}>
        <Route path='clientes' element={<Clientes />} />
      </Route>

      <Route element={<RequireAuth allowedRoles={[ROLES.Admin]} />}>
        <Route path='admin' element={<Admin />} />
      </Route>

      <Route element={<RequireAuth allowedRoles={[ROLES.UserStore, ROLES.Admin]} />}>
        <Route path='encomendas' element={<Encomendas />} />
      </Route>

      {/* catch all*/}
      <Route path="*" element={<Missing />} />
    </Routes>
  );
}

export default App;