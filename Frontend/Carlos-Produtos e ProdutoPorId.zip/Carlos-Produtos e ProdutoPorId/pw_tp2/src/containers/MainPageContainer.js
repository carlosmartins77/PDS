import React from 'react';
import "../App.css"
import {importImages} from "../components/importImages"
import bgimage from "../components/images/mainimage.jpg"




class MainpageContainer extends React.Component{


      
  render(){
  const images = importImages
    //console.log(this.state)
    return (
      <div>
        <img style={{width:"100%"}}src={bgimage}/>
          
      </div>
      
        
    )
  }
  
}

export default MainpageContainer;
