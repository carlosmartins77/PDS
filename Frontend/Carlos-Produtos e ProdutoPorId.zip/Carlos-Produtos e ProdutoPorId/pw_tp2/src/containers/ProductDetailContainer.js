import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { importImages } from '../components/importImages';
import "../App.css"
import { CartButton } from '../components/ProductList';
import addToCart from  './ProductListContainer.js';

class ProductDetailContainer extends React.Component{
    
  constructor(props) {
    super(props)
    this.state = {
        prodDetail: [],
        products: []
    }
  }

  addToCart = (product) =>
  {
    //console.log(product.idProduto)
    let novaQuantidade = parseInt(localStorage.getItem("nProdCarrinhoCompras"))
    let listaProd = JSON.parse(localStorage.getItem("produtoCarrinho")) || []
        //let listaCTudo = JSON.parse(localStorage.getItem("produtoCarrinho")) || []
    let precoProd = parseFloat(localStorage.getItem("precoTotal"))
    
    //console.log("dentro", this.state.products)

    //produtoAux[0].quantidade += 1
    let encontraProd = listaProd.filter(value => value.idProduto == product.idProduto)

    if(encontraProd.length > 0)
    {
      encontraProd[0].quantidade += 1
    }
    else {
      this.state.prodDetail.quantidade += 1
      listaProd.push(this.state.prodDetail)
    }

  // listaProd = listaProd.map((produto) => { 
  //   if(produto.idProduto == product.idProduto)
  //   {
  //     produto.quantidade += 1
  //   }      
  // })

    //console.log("listaProd", listaProd)

   // if(!encontraProd)
   // {
   //   product.quantidade += 1
   //   listaProd.push(product)
   // }

    if (novaQuantidade) {
      localStorage.setItem("nProdCarrinhoCompras", novaQuantidade + 1)
      localStorage.setItem("produtoCarrinho", JSON.stringify(listaProd))
      localStorage.setItem("precoTotal", (precoProd + this.state.prodDetail.preco).toFixed(2))
      document.querySelectorAll('.shopCartButton span')[0].textContent = novaQuantidade + 1;
      //console.log(document.querySelectorAll('.pricetag').textContent)

  } else {
      localStorage.setItem("nProdCarrinhoCompras", 1)
      localStorage.setItem("produtoCarrinho", JSON.stringify(listaProd))
      localStorage.setItem("precoTotal", (this.state.prodDetail.preco).toFixed(2))
      document.querySelectorAll('.shopCartButton span')[0].textContent = 1;
  }
    
    //if(product in this.state.cartProducts)
    //{
    //  product.quantidade +=1
    //}
    //else {
    //  product.quantidade = 0
    //  productAux.push(product)
    //  this.setState({cartProducts : productAux})
    //}
   
   
  }
  

 componentDidMount()
 {
  let idProduto = window.location.pathname.slice(9)
  //console.log(idProduto)

   //console.log("idProduto", idProduto)
   axios.get(`http://localhost:5000/listarProdutoPorId/${idProduto}`, {
       headers: {
           'Content-type': 'application/json',
           'Authorization': `Bearer eyJhbGciOiJIUzI1NiJ9.c2lsdmEucGFzdGVsYXJpYUBvdXRsb29rLmNvbQ.703UrqoZVtpVtqLjGILK05OrnNYUEnN_3URwkOjbymI`
       }
   })
       .then (async res => {
           //console.log("dados", res.data)
           await this.setState({ prodDetail : res.data[0]});

       })
 }

  render(){
    //console.log("XD", this.state.prodDetail.idProduto)
    const images  = importImages
    return (   
<div id = "ProductDetailContainer">
      <div className="row">
        <div className="column left">
          <div><img style={{width: "50%", marginLeft:"25%"}} src = {images[`${this.state.prodDetail.fotoProduto}`]}/></div>
        </div>
        
        <div className="column right">
        <div className="prodPageInfoBox">
          <div className="prodPageName">{this.state.prodDetail.nomeProduto}</div>
          <div className="prodPagePrice">€{this.state.prodDetail.preco}</div>
          <div className="prodPageOthers">Tamanho: {this.state.prodDetail.descricao}</div>
          <div className="prodPageOthers">Vendido por: {this.state.prodDetail.nomeLoja}</div>
          <CartButton onClick={() => this.addToCart(this.state.prodDetail)}>Adicionar ao carrinho</CartButton>
          </div>
        </div>
      </div>
      </div>

      

        
        
  )
  }
  
}

export default ProductDetailContainer;
