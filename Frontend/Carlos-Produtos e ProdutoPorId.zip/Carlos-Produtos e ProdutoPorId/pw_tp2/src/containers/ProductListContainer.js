import React from 'react'
import axios from 'axios'
import ProductList, { BodyBackground } from '../components/ProductList.js'
import SearchProduct from '../components/SearchProduct.js'
import "../App.css"


class ProductListContainer extends React.Component{

  constructor(props) {
    super(props)
    this.state = {
      products : [],
      filteredProducts : [],
      cartProducts: [],
    }
  }
  
  componentDidMount() {
     axios.get(`http://localhost:5000/produto/listarProdutos`, {
      headers: {
          'Content-type': 'application/json',
          'Authorization': `Bearer eyJhbGciOiJIUzI1NiJ9.c2lsdmEucGFzdGVsYXJpYUBvdXRsb29rLmNvbQ.703UrqoZVtpVtqLjGILK05OrnNYUEnN_3URwkOjbymI`
      }
  })
    .then(res => {
      //const products = res.data;
    //console.log("products :)XXX" , this.state.products)

      this.setState({ products : res.data });
      this.setState({ filteredProducts: res.data });
    })
  }

  addToCart = (product) =>
  {
    //console.log(product.idProduto)
    let novaQuantidade = parseInt(localStorage.getItem("nProdCarrinhoCompras"))
    let listaProd = JSON.parse(localStorage.getItem("produtoCarrinho")) || []
        //let listaCTudo = JSON.parse(localStorage.getItem("produtoCarrinho")) || []
    let precoProd = parseFloat(localStorage.getItem("precoTotal"))
    
    //console.log("dentro", this.state.products)

    let produtoAux = this.state.products.filter(value => value.idProduto == product.idProduto)
    //produtoAux[0].quantidade += 1
    let encontraProd = listaProd.filter(value => value.idProduto == product.idProduto)

    if(encontraProd.length > 0)
    {
      encontraProd[0].quantidade += 1
    }
    else {
      produtoAux[0].quantidade += 1
      listaProd.push(produtoAux[0])
    }

  // listaProd = listaProd.map((produto) => { 
  //   if(produto.idProduto == product.idProduto)
  //   {
  //     produto.quantidade += 1
  //   }      
  // })

    //console.log("listaProd", listaProd)

   // if(!encontraProd)
   // {
   //   product.quantidade += 1
   //   listaProd.push(product)
   // }

    if (novaQuantidade) {
      localStorage.setItem("nProdCarrinhoCompras", novaQuantidade + 1)
      localStorage.setItem("produtoCarrinho", JSON.stringify(listaProd))
      localStorage.setItem("precoTotal", (precoProd + produtoAux[0].preco).toFixed(2))
      document.querySelectorAll('.shopCartButton span')[0].textContent = novaQuantidade + 1;
      //console.log(document.querySelectorAll('.pricetag').textContent)

  } else {
      localStorage.setItem("nProdCarrinhoCompras", 1)
      localStorage.setItem("produtoCarrinho", JSON.stringify(listaProd))
      localStorage.setItem("precoTotal", (produtoAux[0].preco).toFixed(2))
      document.querySelectorAll('.shopCartButton span')[0].textContent = 1;
  }
    
    //if(product in this.state.cartProducts)
    //{
    //  product.quantidade +=1
    //}
    //else {
    //  product.quantidade = 0
    //  productAux.push(product)
    //  this.setState({cartProducts : productAux})
    //}
   
    
  }
  
  filterProducts = (event) => {
   
    //let products = this.fetchProducts()
    //console.log(products)
    if(this.state.products) {
      //console.log("entrou")
      let filter = event.target.value; // valor do input
    
      const filteredProducts = this.state.products.filter((item) => item.nomeProduto.toLowerCase().includes(filter.toLowerCase()))
      
      this.setState({filteredProducts: filteredProducts})
      
    }
    
    else return ""
  
  }

  render(){
    //console.log(this.state)
    return (   
        <div>
          <SearchProduct onChange={this.filterProducts}/>
          <ProductList products = {this.state.filteredProducts} /*prodIdModal= {this.prodIdModal}*/ addToCart = {this.addToCart}/>
        </div>
  )
  }
  
}

export default ProductListContainer;
