import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { importImages } from '../components/importImages';
import "../App.css"
import { CartButton } from '../components/ProductList';
import addToCart from  './ProductListContainer.js';

class ProductDetailContainer extends React.Component{
    
    constructor(props) {
        super(props)
        this.state = {
            productsTodos: []
        }
      }
  
 componentDidMount()
 {
  //console.log(idProduto)

   //console.log("idProduto", idProduto)
   axios.get(`http://localhost:5000/produto/listarProdutos`, {
       headers: {
           'Content-type': 'application/json',
           'Authorization': `Bearer eyJhbGciOiJIUzI1NiJ9.c2lsdmEucGFzdGVsYXJpYUBvdXRsb29rLmNvbQ.703UrqoZVtpVtqLjGILK05OrnNYUEnN_3URwkOjbymI`
       }
   })
       .then (async res => {
           //console.log("dados", res.data)
           await this.setState({ productsTodos : res.data});

       })
 }

  render(){
    //console.log("XD", this.state.prodDetail.idProduto)
    return (   
<div id = "ProductDetailContainer">
    <div className="prodPageName">{this.state.productsTodos.nomeProduto}</div>
      </div>

      

        
        
  )
  }
  
}

export default ProductDetailContainer;
