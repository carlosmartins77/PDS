import React from 'react';
import "../App.css"
import {importImages} from "../components/importImages"




class ShoppingCartContainer extends React.Component{

    constructor(props) {
        super(props)
        this.state = {
          cartProducts : [],
          totalPrice:0,
          cartProdQty: 0,
        }
      }

    getCartProds = async () =>
    {
        //console.log("antes", JSON.parse(localStorage.getItem('produtoCarrinho')))
        await this.setState({cartProducts : JSON.parse(localStorage.getItem('produtoCarrinho'))})
        //await this.setState({totalPrice : JSON.parse(localStorage.getItem('precoTotal'))})
        //await this.setState({cartProdQty : JSON.parse(localStorage.getItem('nProdCarrinhoCompras'))})
        //console.log(this.state.cartProducts)
    }

    deleteProd(productId)
    {
        let produtoCarrinho = JSON.parse(localStorage.getItem("produtoCarrinho"))
        let precoTotal = parseFloat(localStorage.getItem("precoTotal"))
        let nProdCarrinhoCompras = parseInt(localStorage.getItem("nProdCarrinhoCompras"))

        let listaNova = produtoCarrinho.filter(produto => produto.idProduto != productId)
        
        localStorage.setItem("produtoCarrinho", JSON.stringify(listaNova))
        //console.log("lista antes", localStorage.getItem("produtoCarrinho"))
        let contarProdutos = produtoCarrinho.filter(produto => produto.idProduto == productId)
        //console.log("contar", contarProdutos)
        //console.log("contarprodutos", parseFloat(contarProdutos[0].preco) * contarProdutos.length)
        localStorage.setItem("precoTotal", (precoTotal - parseFloat(contarProdutos[0].preco) * parseInt(contarProdutos[0].quantidade)).toFixed(2))
        localStorage.setItem("nProdCarrinhoCompras", nProdCarrinhoCompras - contarProdutos[0].quantidade)

        window.location.reload()
    }

    mapCartTable = () => {

        const images  = importImages 
        if(this.state.cartProducts){
            return this.state.cartProducts.map((item, i) => (
                <tr key={i}>
                <td> <img className = "tableImage" src ={images[`${item.fotoProduto}`]}/> </td>    
                <td>{item.nomeProduto}</td>
                <td>{item.descricao}</td>
                <td>{item.nomeLoja}</td>
                <td>{item.quantidade}</td>
                <td>€{(item.preco * item.quantidade).toFixed(2)}</td>
                <td><button onClick={() => this.deleteProd(this.state.cartProducts[i].idProduto)} style={{width: "2vw", padding: "0", fontSize: "1vw", margin: "0"}}>X</button></td>
                </tr>
         ))
        }
        else return ''
    }

    componentDidMount() 
    {
        this.getCartProds()
    }
      
  render(){
   
    //console.log(this.state)
    return (
        <div>
            <div className="center" style ={{marginTop:"2%"}}>
            <div>
            <table>
                <tbody>
                    <tr>
                        <th>Produto</th>
                        <th>Nome</th>
                        <th>Descricao</th>
                        <th>Loja</th>
                        <th>Quantidade</th>
                        <th>Preco</th>
                     </tr>{this.mapCartTable()}

                </tbody>
                <tr className="divPrecoTotal"><x style={{fontWeight:"bold"}}>&nbsp; &nbsp; TOTAL: </x> €{localStorage.getItem("precoTotal")}</tr>
                </table>
                
            </div>
        </div>
    </div>
        
    )
  }
  
}

export default ShoppingCartContainer;
