import React from 'react';


function ShoppingCart() {
    return (
        <div> Carrinho </div>
    );
}

export default ShoppingCart

