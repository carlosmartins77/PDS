import React from 'react';
import styled from "styled-components"
import {importImages} from "./importImages"
import {Link} from 'react-router-dom';
import "../App.css"
import {MdShoppingCart} from 'react-icons/md'

export const Header = styled.header`
display: flex;
justify-content: flex-start;
align-items: center;
padding: 30px 10%;
background-color: #009385;
`

export const Logo = styled.img`
    cursor: pointer;
    width: 100px;
}`

export default class HeaderNav extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      prodQty: 0,
    }
  }

  getCartQty() {
    let novaQuantidade = localStorage.getItem("nProdCarrinhoCompras")

    if (novaQuantidade) {
        document.querySelectorAll('.shopCartButton span')[0].textContent = novaQuantidade
    }
}

  componentDidMount() {
    this.setState({ prodQty: this.getCartQty()})
  }
    

  render() { 
    
    const images  = importImages 
   
    return (
      <Header>
        
        <Logo src = {images[`logo.png`] }/>
        <nav>
            <ul className="navbar_links">
                <li><Link to="/">Página Principal</Link></li>
                <li><Link to="/Product">Produtos</Link></li>
                
            </ul>
        </nav>
        <Link to="ShoppingCart"><button className="shopCartButton "><MdShoppingCart/><span>0</span></button></Link>
   
      </Header>
    )
  }
}