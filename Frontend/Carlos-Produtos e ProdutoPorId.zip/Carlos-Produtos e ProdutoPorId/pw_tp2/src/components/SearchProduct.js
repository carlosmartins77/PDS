import React from 'react';
import axios from 'axios';
import styled from "styled-components"

export const SearchProd = styled.input`
  background-color: #ffffff;
  border-radius: 15px;
  margin-left: 40%;
  border: 1px solid #e1e1e1;
  width: 20%;
  height: 25px;
  margin-bottom: 1%;
  margin-top: 1%;
  outline: none;
  padding-left: 1%;
`


export default class SearchProduct extends React.Component {

  render() {
    return (
          <SearchProd onChange = {this.props.onChange} type="text "placeholder="Procurar.."/>
    )
  }
}