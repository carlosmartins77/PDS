const importAll = (req) => {
    let images = {};
    req.keys().forEach((item) => {
      images[item.replace("./", "")] = req(item);
    });
    return images;
  };
  
  export const importImages = importAll(require.context("./images", false, /\.(png|jpe?g|svg)$/));