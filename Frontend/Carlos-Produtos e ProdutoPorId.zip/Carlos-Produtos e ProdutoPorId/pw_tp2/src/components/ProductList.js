import React from 'react';
import styled from "styled-components"
import {importImages} from "./importImages"
import {Link} from 'react-router-dom'
import axios from 'axios'
import "../App.css"



export const Product = styled.div`
    background-color: #fff;
    height: 390px;
    border: 1px solid #e1e1e1;
`
export const BodyBackground = styled.div`
  background-color: #f3f3f3;
`
export const Grid = styled.div`
    grid-template-columns: repeat(auto-fill, minmax(270px, auto));
    grid-gap: 10px;
    display: grid;
    justify-content: center;
`
export const NameTag = styled.p`
    font-weight: bold;
    margin: 20px 0px 0px 20px;
    color: #32312d;
    font-size: 22px;
`
export const DescricaoTag = styled.p`
    color: #32312d;
    margin: 4px 0px 0px 20px;
    font-size: 15px;
    line-height: 13px;
    font-weight: 400;
`
export const LojaTag = styled.p`
    color: #32312d;
    margin: 15px 0px 0px 20px;
    font-size: 10px
`
export const PriceTag = styled.p`
    color: #ff675d;
    margin: 8px 0px 0px 20px;
    font-weight: 500;
    word-spacing: -3px;
`
export const Button = styled.button`
    margin-left: 20px;
    padding: 9px 25px;
    background-color: #009385;
    border: none;
    border-radius: 20px;
    cursor: pointer;
    &:hover{
      background-color: #02554d9e;
    }
`
export const CartButton = styled(Button)`
    color: #009385;
    font-size: 17px;
    display: block;
    width: 100%;
    margin: 0px;
    border-radius: 0;
    margin: 20px 0px 0px 0px;
    background: #f3f3f3;
    text-transform: uppercase;
    &:hover {
      background-color: #009385;
      color: #f3f3f3;
  }
`
export const ProdImage = styled.img`
    height: 50%;
    margin: auto;
    margin-top: 20px;
    display: block;
    max-width: 200px;
`

export default class ProductList extends React.Component {

  listProducts = () =>
  {
    const images  = importImages 
   
    if(this.props.products) {
        return ( 
        this.props.products
          .map((product, i) =>
          <div key={i}  /*class ="prodInfo" onClick={() => this.props.prodIdModal(product.idProduto)}*/>
            <div>
            <Product> 
                <Link to = {`/Product/${product.idProduto}`}>
                  <ProdImage src = {images[`${product.fotoProduto}`]}/> 
                  <NameTag>{product.nomeProduto}</NameTag>
                  <DescricaoTag>{product.descricao}</DescricaoTag>
                  <LojaTag>{product.nomeLoja}</LojaTag>
                  <PriceTag>€{product.preco}</PriceTag>
              </Link>
              <CartButton onClick={() => this.props.addToCart(product)}>Adicionar ao carrinho</CartButton>
            </Product></div>
            <Button><Link to = {`/Product/Todos`}></Link></Button>
            </div>)

            
          )
      }
      else return ''
  }


  render() { 
      //console.log("XD", this.state.prodDetail)
   
    return (
      
      <Grid>
        {this.listProducts()}
      </Grid>
    )
  }
}