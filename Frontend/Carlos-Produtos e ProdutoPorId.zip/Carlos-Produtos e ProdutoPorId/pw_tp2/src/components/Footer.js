import React from 'react';
import styled from "styled-components"
import "../App.css"

export const Footer = styled.footer`
    height: 115px;
    background-color: #009385;
    margin-top: 3%;
    
}`

export default class FooterNav extends React.Component {


  render() { 
    
    return (
     <Footer/>
    )
  }
}