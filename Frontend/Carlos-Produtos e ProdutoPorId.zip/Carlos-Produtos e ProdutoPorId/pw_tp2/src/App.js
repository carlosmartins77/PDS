import React from 'react';
import ProductListContainer from './containers/ProductListContainer.js';
import ShoppingCartContainer from './containers/ShoppingCartContainer.js';
import ProductDetailContainer from './containers/ProductDetailContainer.js';
import TodosProdutosContainer from './containers/TodosProdutos';

import MainpageContainer from './containers/MainPageContainer.js';
import Header from './components/Header.js';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';  
import FooterNav from './components/Footer.js';


class App extends React.Component{

  

  render(){
    //console.log(this.state)
    return (   
      <Router>
            <Header/>
            <Switch>
              <Route exact path="/">
                <MainpageContainer/>
              </Route>
              <Route exact path="/Product">
                <h1 style={{textAlign:"center", paddingTop: "2%"}}>Lista de produtos</h1>
                <ProductListContainer/>
              </Route>
              <Route path="/ShoppingCart">
                <ShoppingCartContainer/>
              </Route>
              <Route exact path="/Product/:idProduto">
                <ProductDetailContainer/>
              </Route>
              <Route exact path="/Product/Todos">
                <TodosProdutosContainer/>
              </Route>
            </Switch>
            
        </Router>
      
      
  )
  }
  
}

export default App;
