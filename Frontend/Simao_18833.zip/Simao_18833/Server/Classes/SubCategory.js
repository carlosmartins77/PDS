class SubCategory {
    constructor(SubCategoria, Categoria) {
        this.subcategoria = SubCategoria;
        this.categoria = Categoria
    }
}

module.exports = SubCategory;