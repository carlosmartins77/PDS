class Perfil{
    constructor(Name, Email, Contact){
        this.name = Name; 
        this.email = Email;
        this.contact = Contact;
    }
}

module.exports = Perfil;