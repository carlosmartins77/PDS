class Category {
    constructor(Categoria) {
        this.categoria = Categoria;
    }
}

module.exports = Category;