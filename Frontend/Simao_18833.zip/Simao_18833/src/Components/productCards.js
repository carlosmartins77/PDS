import React, { Component } from 'react';
import styled from 'styled-components';

const ProductList = styled.div`
    display: flex;
    flex-wrap: wrap;
    margin-top: 20px;
`;
const Product = styled.div`
    display: flex;
    flex-direction: column;
    box-shadow: 1px 1px 4px #cdcdcdcc;
    border-radius: 8px;
    background-color: #fff;
    margin-right: 30px;
    margin-bottom: 30px;
    min-width: 200px;
    border: 2px solid #62b3be;
`;
const ProductImg = styled.div`
    padding: 10px;
    align-self: center;
`;
const ProductDetails = styled.div`
    margin-top: 15px;
    background-color: #198f9f45;
    padding: 10px;
`;
const BlueLine = styled.div`
    border-bottom: 3px solid #62b3be;
    width: 100%;
`;
const Btn = styled.input`
    border-radius: 6px;
    box-shadow: 1px 1px 4px #acababcc;
    background-color: #62b3be;
    color: #fff;
    border: 0px;
    width: 100%;
    padding: 5px;
    transition: 0.4s ease-in-out;
    border: 2px solid #62b3be;
    cursor: pointer;
    &:hover {
    background-color: #fff;
    color: #62b3be;
    }
`;

class ProductCards extends Component {

    constructor(props) {
        super(props);
    }   

    // Lists all products
    listProducts = () => {
        const { products } = this.props;
        if (products) {
            return products.map( (prod, i) => { 
                return (
                    <Product key={i}>
                        <ProductImg><img src={require ("../images/" + prod["fotoProduto"])} width="100px"/></ProductImg>
                        <ProductDetails>
                            <span>{prod["nomeProduto"]}</span><br/>
                            <span>Quantidade: {prod["quantidade"]}</span><br/><br/>
                            <BlueLine/><br/>
                            <span>Preço: {prod["preco"]}€</span><br/><br/>
                            <Btn type="button" value="Comprar" onclick={prod["idProduto"]}/>
                        </ProductDetails>
                    </Product>
                );
            });
        }
        else
            return '';
    }

    render() {
        return (
            <ProductList>{this.listProducts()}</ProductList>
        );
    }
} 

export default ProductCards;