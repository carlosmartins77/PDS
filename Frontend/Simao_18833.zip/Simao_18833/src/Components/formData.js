import React, { Component } from 'react';
import styled from 'styled-components';

const Fields = styled.div`
    margin-top: 20px;
`;
const Field = styled.div`
    margin-top: 5px;
    margin-bottom: 5px;
    display: flex;
    flex-direction: column;
    > span {
        margin-bottom: 5px;
    }
`;
const Btn = styled.input`
    border-radius: 6px;
    box-shadow: 1px 1px 4px #acababcc;
    background-color: #62b3be;
    color: #fff;
    border: 0px;
    width: 100%;
    padding: 5px;
    transition: 0.4s ease-in-out;
    border: 2px solid #62b3be;
    cursor: pointer;
    :hover {
        background-color: #fff;
        color: #62b3be;
    }
`;

class FormData extends Component {

    constructor(props) {
        super(props); 
        this.state = {
            name: '',
            contact: null,
            email: ''
        }
    }

    componentDidUpdate(prevProps) {
        // When props change, saves new props on state
        if (prevProps != this.props) {
            const { name, email, contact } = this.props.profile;

            this.setState({ name: name });
            this.setState({ contact: contact });
            this.setState({ email: email });
        }
    }
    
    // When typing on input stores value on state
    handleChange = event => {
        event.target.value = event.target.value;
        // saves new value on state using input id as key
        // variable is inside [] to use it's value as key
        this.setState({ [event.target.id] : event.target.value })
    }

    // Creates data form with customer data
    listFields = () => {
        if (this.props.profile) {
            const { name, contact, email } = this.state;
            const profile = { name: name , contact: contact, email: email }
            return (       
                <div>
                    <Field>
                        <span>Nome</span>
                        <input type="text" id="name" value={this.state.name || ''} onChange={this.handleChange}/>
                    </Field>
                    <Field>
                        <span>Contacto</span>
                        <input type="number" id="contact" value={this.state.contact || ''} onChange={this.handleChange}/>
                    </Field> 
                    <Field>
                        <span>Email</span>
                        <input type="email" id="email" value={this.state.email || ''} onChange={this.handleChange}/>
                    </Field>
                    <br/>
                    <Btn type="button" value="Atualizar dados" onClick={() => this.props.updateProfile()} /><br/><br/>
                    <span id="error"></span>
                </div>
            );
        }
        else
            return '';
    }

    render() {
        return (
            <Fields>{this.listFields()} </Fields>
        );
    }
} 

export default FormData;