import React, { Component } from 'react';
import styled from 'styled-components';

const CardRow = styled.div`
    margin: 10px 0px;
    padding-left: 10px;
    display: flex;
    background-color: #fff;
    box-shadow: 2px 3px 6px #7e7e7e61;
    border-radius: 8px;
    border: 2px solid #198f9fad;
`;
const CardMedal = styled.div`
    padding: 10px 0px 10px 0px;
`;
const CardDetails = styled.div`
    padding: 10px 10px 10px 10px;
    border-radius: 0px 8px 8px 0px;
    background-color: #fff;
    border-left: 2px solid #198f9f30;
    margin: 5px 0px 5px 10px;
    > span {
        color: #505050;
    }
`;
const Rows = styled.div`
    overflow-y: auto;
    max-height: 700px;
    margin-top: 10px;
`;
const LightText = styled.span`
    color: #505050;
`;

class CardRows extends Component {

    constructor(props) {
        super(props); 
    }

    // Lists all customer's medals
    listMedals = () => {
        if (this.props.medals[0]) {
            return this.props.medals.map( (medal, i) => (
                <CardRow key={i}>
                    <CardMedal>
                        <img src={require('../images/' + medal["icon"])} width="50px"/>
                    </CardMedal>
                    <CardDetails>
                        <strong>{medal["nomeMedalha"]}</strong><br/>
                        <LightText>Desbloqueada a {medal["dataDesbloqueio"].slice(0, 10)}</LightText>
                    </CardDetails>
                </CardRow>
            ));
        }
        else
            return '';
    }

    render() {
        return (
            <Rows>{this.listMedals()}</Rows>    
        );
    }
} 

export default CardRows;