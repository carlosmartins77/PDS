import React from "react";
import './App.css';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link,
  useLocation
} from 'react-router-dom';
import styled from 'styled-components';

import logo from './images/logo.png';
import Profile from './Containers/Profile';
import Products from './Containers/Products';

const Navbar = styled.div`
  padding: 20px 0px 20px 180px;
  background-color: #fff;
  font-size: 30px;
  box-shadow: 1px 1px 6px #323232;
  display: flex;
  align-items: center;
  > * {
    margin-right: 20px;
  }
  /* Resolutions */
  @media screen and (max-width: 1100px) {
    padding-left: 10%;
  }
  /* Table or big smartphones */
  @media screen and (max-width: 870px) {
    padding-left: 20%;
  }
  /* Mobile */
  @media screen and (max-width: 425px) {
    padding-left: 4.5%;
}
`;
const Inactive = styled.div`
  border-bottom: 3px solid #fff;
  position: relative;
`;
const NavLink = styled.div`
  &:hover > ${Inactive} {
    border-bottom: 3px solid #62b3be;
    -webkit-animation: inactiveAnim 1s;
    -moz-animation: inactiveAnim 1s;
    animation: inactiveAnim 1s;
  }
  @keyframes inactiveAnim {
    from {width: 0;}
    to {width: 100%;}
  }
`;
const Active = styled.div`
  border-bottom: 3px solid #62b3be;
  position: relative;
  animation: activeAnim 1s;
  -webkit-animation: activeAnim 1s;
  -moz-animation: activeAnim 1s;
  @keyframes activeAnim {
    from {width: 0;}
    to {width: 100%;}
  }
`;
const Alink = styled.div`

`;
const A = styled.div``;

class App extends React.Component {

  // Constructor
  constructor(props) {
    super(props);
    this.state = {
      currentPath: '',
    }
  }

  // Generates navbar and puts blue underline on active menu page
  generateNavBar = () => {
    let path = window.location.pathname;
    let profileStatus;
    let productStatus;

    if (path == '/profile') {
      productStatus = <Inactive />;
      profileStatus = <Active />;
    }
    else {
      productStatus = <Active />;
      profileStatus = <Inactive />;
    }

    return (
      <Navbar>
        <img src={logo} width="50px"/>
        <NavLink>
          <Link to="/" onClick={this.updateNav}>Produtos</Link>
          {productStatus}
        </NavLink>
        <NavLink>
          <Link to="/profile" onClick={this.updateNav}>Perfil</Link>
          {profileStatus}
        </NavLink>
      </Navbar>
    );
  };

  // Updates nav when changing page
  updateNav = () => {
    this.setState({ currentPath: window.location.pathname });
  }

  render() {
    return (
      <Router>
        {this.generateNavBar()}

        <Routes>
          <Route path="/profile" element={<Profile />} />
          <Route path="/" element={<Products />} />
        </Routes>
      </Router>
    );
  }
}

export default App;
