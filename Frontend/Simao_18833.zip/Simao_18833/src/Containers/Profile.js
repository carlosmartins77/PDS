import React, { Component } from 'react';
import styled from 'styled-components';
import CardRows from '../Components/cardRows';
import FormData from '../Components/formData';


/* Profile */
const Content = styled.div`
    margin-left: 180px;
    margin-right: 180px;
    padding-top: 50px;
    display: flex;
    justify-content: space-between;
    /* Resolutions */
    @media screen and (max-width: 1100px) {
        margin-left: 10%;
        margin-right: 10%;
    }
    /* Table or big smartphones */
    @media screen and (max-width: 870px) {
        flex-direction: column;
        margin-left: 20%;
        margin-right: 10%;
    }
    /* Mobile */
    @media screen and (max-width: 425px) {
        margin-left: 4.5%;
    }
`;

const ProfileData = styled.div`
    display: flex;
    justify-content: space-between;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 1px 1px 6px #323232;
    padding: 20px;
    padding-right: 465px;
    float: left;
    /* animation */
    position: relative;
    animation: profileMove 1.5s;
    @keyframes profileMove {
        from {left: -200px;}
        to {left: 0px;}
    }
    /* Resolutions */
    @media screen and (max-width: 1465px) {
        padding-right: 35%;
    }
    @media screen and (max-width: 1350px) {
        padding-right: 25%;
    }
    @media screen and (max-width: 1220px) {
        padding-right: 75px;
    }
    @media screen and (max-width: 1100px) {
        padding-right: 75px;
    }
    /* Table or big smartphones */
    @media screen and (max-width: 870px) {
        padding-right: 0;
        width: 320px;
    }
`;
const Title = styled.div`
    border-bottom: 1px solid #198f9fad;
    font-size: 1.5em;
    font-weight: bold;
    padding-top: 20px;
    padding-bottom: 10px;
    margin-bottom: 15px;
`;


/* Medals */
const Card = styled.div`
    box-shadow: 1px 1px 6px #323232;
    border-radius: 8px;
    padding: 20px;
    max-width: 30%;
    background-color: #fff;
    float: right;
    min-width: 300px;
    /* animation */
    position: relative;
    animation: cardMove 1.5s;
    @keyframes cardMove {
        from {right: -200px;}
        to {right: 0px;}
    }
    /* Table or big smartphones */
    @media screen and (max-width: 870px) {
        margin-top: 40px;
    }
`;

class Profile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            medals: {},
            profile: {}
        }
    }

    componentDidMount () { 
        this.getMedals(1);
        this.getProfile();
    }

    // Fetches all client medals and stores on state
    getMedals = clientId => {
        const token = "eyJhbGciOiJIUzI1NiJ9.YXJpc3RldS5wZXJlaXJhQGdtYWlsLmNvbQ.xGEYi6cznV2ZGwU1phBOpVTJlVT3FIQEtx1d4VcScE8";
        fetch('http://localhost:5000/cliente/listarMedalhas', 
        {
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
                'Authorization': `Bearer ${token}`,
            },
            body: JSON.stringify({
                'clienteId': clientId,
            })
        }
        )
        .then( response => response.json())
        .then( response => {
            this.setState({ medals: response });
        });
    }

    // Fetches customer profile data and stores on state
    getProfile = () => {
        const token = "eyJhbGciOiJIUzI1NiJ9.am9hby5mZXJuYW5kZXNAY29kZXNvbHV0aW9ucy5wdA.TEow1rNQRINYiToJ6z5MaR6nOyoBMXve3gsnsPrjybw";
        fetch('http://localhost:5000/mostarPerfil', 
        {
            method: 'POST',
            headers: {
                'Content-type': 'application/json',
                'Authorization': `Bearer ${token}`,
            }
        }
        )
        .then( response => response.json())
        .then( response => {
            this.setState({ profile: response });
        });
    }


    render() {
        return (
            <div>
                <Content>
                    <ProfileData>
                        <div>
                            <Title>
                                <span>Dados de Conta</span>
                            </Title>
                            <FormData profile={this.state.profile} />
                        </div>
                    </ProfileData>
                    <Card>
                        <Title>
                            <span>Medalhas</span>
                        </Title>
                        {<CardRows medals={this.state.medals} />}
                    </Card>
                </Content>
            </div>
        );
    }

}

export default Profile;