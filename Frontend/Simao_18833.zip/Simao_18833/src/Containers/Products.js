import React from 'react';
import styled from 'styled-components';

import ProductCards from '../Components/productCards';

const ProductList = styled.div`
    margin: 50px 180px 0px 180px;
    background-color: #fff;
    border-radius: 8px;
    padding: 20px;
    /* animation */
    position: relative;
    animation: product-list 1s;
    @keyframes product-list {
        from {bottom: -200px;}
        to {bottom: 0px;}
    }
    /* Resolutions */
    @media screen and (max-width: 1100px) {
        margin: 50px 180px 0px 10%;
    }
    /* Table or big smartphones */
    @media screen and (max-width: 870px) {
        margin: 50px 180px 0px 20%;
        min-width: 210px;
    }
    /* Mobile */
    @media screen and (max-width: 425px) {
        margin: 50px 180px 0px 4.5%;
    }
`;
const FiltersBar = styled.div`
    display:flex;
    /* Table or big smartphones */
    @media screen and (max-width: 870px) {
        flex-direction: column;
    }
`;
const Search = styled.input`
    margin-left: 20px;
    /* Table or big smartphones */
    @media screen and (max-width: 870px) {
        margin: 10px 0px 0px 0px;
        width: auto!important;
    }
`;


class Products extends React.Component {
    constructor(props) {
        super(props); 

        this.state = {
            productsList: [],
            changedProdList: [],
            order: 0,
            search: ''
        };
    }

    componentDidMount() {
        this.getProducts();
    }

    // Fetches all products and orders them by name A-Z
    getProducts = () => {
        var token = "eyJhbGciOiJIUzI1NiJ9.c2lsdmEucGFzdGVsYXJpYUBvdXRsb29rLmNvbQ.703UrqoZVtpVtqLjGILK05OrnNYUEnN_3URwkOjbymI";
        fetch('http://localhost:5000/produto/listarProdutos', 
        {
            method: 'GET',
            headers: {
                'Content-type': 'application/json',
                'Authorization': `Bearer ${token}`,
            }
        }
        )
        .then( response => response.json())
        .then( response => {
            this.setState({ productsList: response });
            this.setState({ changedProdList: response });
            this.orderNameAZ(response);
        });
    }

    // Orders Product list by price and returns new list - ASC order
    orderPriceAsc = (changedProdList) => {
        if (!changedProdList)
            return [];

        const newList = changedProdList.sort((a, b) => a.preco - b.preco);
        return newList;
    }
    
    // Orders Product list by price and returns new list - DESC order
    orderPriceDesc = (changedProdList) => {
        if (!changedProdList)
            return [];

        const newList = changedProdList.sort((a, b) => b.preco - a.preco);
        return newList;
    }
    
    // Orders Product list by name and returns new list - A-Z order
    orderNameAZ = (changedProdList) => {
        if (!changedProdList)
            return [];

        const newList = changedProdList.sort((a, b) => {
            if (a.nomeProduto.toLowerCase() < b.nomeProduto.toLowerCase())
                return -1;
            else
                return 1;
        });
        return newList;
    }
    
    // Orders Product list by name and returns new list - Z-A order
    orderNameZA = (changedProdList) => {
        if (!changedProdList)
            return [];
            
        const newList = changedProdList.sort((a, b) => {
            if (a.nomeProduto.toLowerCase() > b.nomeProduto.toLowerCase())
                return -1;
            else
                return 1;
        });
        return newList;
    }

    // calls order functions depending on select option
    handleChange = value => {
        let products = this.state.changedProdList;
        let newList;
        if (value == 0) {
            if (this.state.search) {
                newList = this.orderNameAZ(products);
                this.setState({ changedProdList: newList, order: value });
            }
            else {
                this.getProducts();
            }
            return 0;
        }
        else if(value == 1)
            newList = this.orderPriceAsc(products);
        else if(value == 2)
            newList = this.orderPriceDesc(products);
        else if(value == 3) {
            newList = this.orderNameAZ(products);
        }
        else if(value == 4)
            newList = this.orderNameZA(products);
        this.setState({ changedProdList: newList, order: value });
    }

    // Searches products on product list with keyword typed on search input on it's name
    searchProduct = event => {
        const { value } = event.target;
        const { order } = this.state;
        let products;
        products = this.state.productsList;
        let newProducts;
        newProducts = products.filter(product => product.nomeProduto.toLowerCase().includes(value));
        if (!newProducts) {
            newProducts = products;
        }
        if (order) {    
            this.setState({changedProdList: newProducts, search: value}, () => this.handleChange(order));
        }
        else
            this.setState({changedProdList: newProducts, search: value});
    }

    render() {
        return (
            <ProductList>
                <FiltersBar>
                    <select name="order" id="order" onChange={event => this.handleChange(event.target.value)}>
                        <option value="0" defaultValue>Ordem</option>
                        <option value="1">Preço ASC</option>
                        <option value="2">Preço DESC</option>
                        <option value="3">Nome A-Z</option>
                        <option value="4">Nome Z-A</option>
                    </select>
                    <Search type="text" placeholder="Pesquisar produto..." value={this.state.search} onChange={this.searchProduct} />
                </FiltersBar>
                <ProductCards products={this.state.changedProdList} />
            </ProductList>
        );
    }

}

export default Products;