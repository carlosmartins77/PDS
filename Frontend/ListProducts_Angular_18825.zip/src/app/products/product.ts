export interface IProduct {
  productId: number;
  productName: string;
  productCode: string;
  validDate: string;
  price: number;
  description: string;
  imageUrl: string;
  quantity: number;
  total: number;
}
