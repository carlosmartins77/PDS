import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { InitialComponent } from './home/initial.component';
import { RouterModule, Routes } from '@angular/router';
import { ProductModule } from './products/product.module';
import { CartComponent } from './cart/cart.component';
import { ProductListComponent } from './products/product-list.component';

const routes: Routes = [
  { path:'', redirectTo:'products',pathMatch:'full' },
  { path:'products', component: ProductListComponent },
  { path:'cart', component: CartComponent },
  { path: 'initial', component: InitialComponent },
  { path: '', redirectTo: 'initial', pathMatch: 'full' },
  { path: '**', redirectTo: 'initial', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    AppComponent,
    InitialComponent,
    CartComponent,
  ],
  imports: [
    RouterModule.forRoot(routes),
    BrowserModule,
    HttpClientModule,
    ProductModule
  ],
  exports: [RouterModule],

  bootstrap: [AppComponent]
})

export class AppModule { }
