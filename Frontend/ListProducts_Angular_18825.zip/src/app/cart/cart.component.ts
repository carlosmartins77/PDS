import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/cart/cart.service';
import { IProduct } from "src/app/products/product";

@Component({
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  public products : any = [];
  public grandTotal !: number;
  constructor(private cartService : CartService) { }

  ngOnInit(): void {
    this.cartService.getProducts()
    .subscribe(products=>{
      this.products = products;
      this.grandTotal = this.cartService.getTotalPrice();
    })
  }

  removeProduct(product: any){
    this.cartService.removeCartProduct(product);
  }

  emptycart(){
    this.cartService.removeAllCart();
  }
}
