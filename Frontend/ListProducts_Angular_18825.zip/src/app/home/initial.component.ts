import { Component } from '@angular/core';

@Component({
  templateUrl: './initial.component.html',
  styleUrls: ['initial.component.css'],
})
export class InitialComponent {
  public pageTitle = 'ProductFoodSustainability';
}
